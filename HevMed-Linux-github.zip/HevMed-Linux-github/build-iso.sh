#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"

if [[ "$(id -u)" -ne 0 ]]; then
  echo "Bu betik root yetkisiyle çalıştırılmalı: sudo ./build-iso.sh" >&2
  exit 1
fi

command -v lb >/dev/null || { echo "live-build kurulu değil." >&2; exit 1; }

lb clean --purge || true
lb config \
  --mode debian \
  --architectures i386 \
  --distribution bookworm \
  --mirror-bootstrap http://deb.debian.org/debian \
  --mirror-binary http://deb.debian.org/debian \
  --mirror-chroot http://deb.debian.org/debian \
  --mirror-chroot-security http://security.debian.org/debian-security \
  --mirror-binary-security http://security.debian.org/debian-security \
  --mirror-debian-installer http://deb.debian.org/debian \
  --parent-mirror-bootstrap http://deb.debian.org/debian \
  --parent-mirror-chroot http://deb.debian.org/debian \
  --parent-mirror-chroot-security http://security.debian.org/debian-security \
  --parent-mirror-binary http://deb.debian.org/debian \
  --parent-mirror-binary-security http://security.debian.org/debian-security \
  --parent-mirror-debian-installer http://deb.debian.org/debian \
  --security false \
  --volatile false \
  --keyring-packages debian-archive-keyring \
  --hdd-label HEVMED_32 \
  --linux-packages linux-image \
  --linux-flavours 686 \
  --initsystem systemd \
  --memtest none \
  --archive-areas "main contrib non-free non-free-firmware" \
  --binary-images iso-hybrid \
  --debian-installer false \
  --bootappend-live "boot=live components username=hevmed live-config.nocomponents locales=tr_TR.UTF-8 keyboard-layouts=tr net.ifnames=0" \
  --iso-application "HevMed Linux" \
  --iso-publisher "HevMed Project" \
  --iso-volume "HEVMED_32"

sed -i 's/^LB_SYSLINUX_THEME=.*/LB_SYSLINUX_THEME="live-build"/' config/binary

mkdir -p /root/isolinux
ln -sf /usr/lib/ISOLINUX/isolinux.bin /root/isolinux/isolinux.bin
ln -sf /usr/lib/syslinux/modules/bios/vesamenu.c32 /root/isolinux/vesamenu.c32

lb build
mv -f binary.hybrid.iso "HevMed-Linux-i386.iso"
echo "Oluşturuldu: HevMed-Linux-i386.iso"
