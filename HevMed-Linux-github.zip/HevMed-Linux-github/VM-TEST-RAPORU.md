# HevMed Linux Sanal Makine Test Raporu



- QEMU `qemu-system-i386`
- Makine: `pc`
- CPU: Pentium III uyumluluğu
- RAM: 1024 MB
- BIOS: SeaBIOS
- Ağ: QEMU user-mode networking, e1000
- ISO: `HevMed-Linux-i386.iso`


| Test | Sonuç |
|---|---|
| ISO 9660 ve BIOS önyükleme | Başarılı |
| Syslinux önyükleme modülleri | Başarılı; eksik `ldlinux.c32` düzeltildi |
| Live boot menüsü | Başarılı |
| Kernel ve initramfs yükleme | Başarılı |
| Live squashfs bağlama | Başarılı |
| systemd başlatma | Başarılı |
| Sanal makinenin 5 dakika çalışması | Başarılı |
| LightDM grafik giriş ekranı | Başarısız; son görüntü siyah ekran |
| Masaüstü oturumu | Doğrulanamadı |


İlk testte ISO, `ldlinux.c32` bulunamadığı için önyüklemiyordu. Syslinux modülleri ISO’ya eklenerek bu hata giderildi. İkinci testte ISO önyükleme menüsüne ulaştı ve Live sistemi başlattı.

Daha sonra sistemin `sysvinit` ile başladığı ve `user-setup` betiğinin systemd beklediği görüldü. Derleme `systemd` kullanacak şekilde düzeltildi. Güncel ISO systemd servislerini başlatıyor, live squashfs dosya sistemini bağlıyor ve sanal makinede çalışır durumda kalıyor.

Buna rağmen yaklaşık beş dakikalık QEMU testinin sonunda LightDM giriş ekranı görünmedi; ekran siyah kaldı. Bu nedenle mevcut sürüm **önyükleme ve Live sistem seviyesi testini geçti, ancak grafik masaüstü testi başarısız olduğu için tam kullanılabilir sürüm olarak onaylanmadı**.


![QEMU son ekranı](hevmed-vm-test-final.png)

Güncel ISO SHA-256:

```text
ed334ca0a1de8c6a04e936e7d52fbbbefc69a478be407b69bb9c4aec6b3b50c4
```
