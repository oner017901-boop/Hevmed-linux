# HevMed Linux

HevMed Linux is a lightweight Debian Bookworm i386 live distribution with Openbox, Tint2, Firefox ESR, NetworkManager and I2P support.

## Build

Run the build script on a Debian-based build machine with live-build installed:

    sudo ./build-iso.sh

The generated ISO is named `HevMed-Linux-i386.iso`.

## Architecture

- Debian Bookworm
- i386 32-bit
- ISO hybrid image
- Openbox and Tint2 desktop
- I2P support through i2pd
- QEMU test configuration included in the project documentation

## Project status

The ISO boots in QEMU and starts X with a terminal. Tint2 and the complete window-management session still require further validation before production use.
