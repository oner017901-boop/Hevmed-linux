# Arayüz ve giriş ekranı

Giriş ekranında sabit bir kullanıcı adı bulunmayacak. LightDM, sistemdeki gerçek kullanıcıları listeleyecek; ayrıca manuel kullanıcı adı ve misafir oturumu seçenekleri açık olacaktır.

Tema hedefi:

- Siyah/gece arka planı
- Mor vurgu rengi
- HevMed Linux kurt-ay logosu
- Kullanıcı seçici
- Parola alanı
- Kapat / Yeniden Başlat / Askıya Al

Eklenen `assets/hevmed-reference.png` görseli tasarım referansıdır; üretim ISO'sunda ayrı logo, duvar kâğıdı ve giriş ekranı görsellerine bölünmelidir.
